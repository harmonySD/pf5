let ligne (m : 'a Matrix.t) (i : int) : 'a list =
  failwith "TODO"
;;

let colonne (m : 'a Matrix.t) (j : int) : 'a list =
  failwith "TODO"
;;

let diagonale (m : 'a Matrix.t) (k : int) : 'a list =
  failwith "TODO"
;;

let rec valeur_constante (l : 'a option list) : 'a option =
  failwith "TODO"
;;

let gagnant_lignes (m : 'a option Matrix.t) : 'a option =
  failwith "TODO"
;;

let gagnant_colonnes (m : 'a option Matrix.t) : 'a option =
  failwith "TODO"
;;

let gagnant_diagonales (m : 'a option Matrix.t) : 'a option =
  failwith "TODO"
;;

let gagnant (m : 'a option Matrix.t) : 'a option =
  failwith "TODO"
;;

let termine (m : 'a option Matrix.t) : bool =
  failwith "TODO"
;;
