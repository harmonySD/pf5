let plateau_initial (taille : int) : plateau =
  failwith "TODO"
;;

let coup_legal (plateau : plateau) (coup : coup) : bool =
  false
;;

let coup_des_coordonnees_absolues
      (plateau : plateau)
      (dernier_coup : coup option)
      (nb_joueurs : int)
      (x , y : int*int)
    : coup option =
  None
;;
