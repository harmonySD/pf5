
let matrix_map (f: 'a -> 'b) (m: 'a Matrix.t): 'b Matrix.t =
  failwith "TODO"
;;

let gagnant_dim_2 (plateau : plateau): int option =
  None
;;

let termine_dim_2 (plateau : plateau) : bool =
  false
;;
