type plateau = int option Matrix.t

type coup =
  { joueur : int
  ; position : int * int
  }
