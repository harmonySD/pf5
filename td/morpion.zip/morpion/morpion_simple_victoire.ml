let ligne (m : 'a Matrix.t) (i : int) : 'a list =
  []
;;

let colonne (m : 'a Matrix.t) (j : int) : 'a list =
  []
;;

let diagonale (m : 'a Matrix.t) (k : int) : 'a list =
  []
;;

let rec valeur_constante (l : 'a option list) : 'a option =
  None
;;

let gagnant_lignes (m : 'a option Matrix.t) : 'a option =
  None
;;

let gagnant_colonnes (m : 'a option Matrix.t) : 'a option =
  None
;;

let gagnant_diagonales (m : 'a option Matrix.t) : 'a option =
  None
;;

let gagnant (m : 'a option Matrix.t) : 'a option =
  None
;;

let termine (m : 'a option Matrix.t) : bool =
  false
;;
