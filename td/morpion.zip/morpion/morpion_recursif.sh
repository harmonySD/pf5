#!/bin/sh

set -e
mkdir -p _build
version=$(ocamlc -v | head -1 | cut -f 5 -d ' ')
cp -f outputs_${version}/* _build/
if [ -e 7.1_morpion_simple_debut.ml ]; then
    mv -v 7.1_morpion_simple_debut.ml morpion_simple_debut.ml
fi
if [ -e 7.2_morpion_simple_victoire.ml ]; then
    mv -v 7.2_morpion_simple_victoire.ml morpion_simple_victoire.ml
fi
if [ -e 7.3_morpion_recursif_debut.ml ]; then
    mv -v 7.3_morpion_recursif_debut.ml morpion_recursif_debut.ml
fi
if [ -e 7.4_morpion_recursif_victoire.ml ]; then
    mv -v 7.4_morpion_recursif_victoire.ml morpion_recursif_victoire.ml
fi
cp *.mli *.ml _build/
cd _build
ocamlc -open Morpion_simple_prelude -c morpion_simple_debut.ml
ocamlc -c morpion_simple_victoire.ml
ocamlc -open Morpion_recursif_prelude -c morpion_recursif_debut.ml
ocamlc -open Morpion_recursif_prelude -c morpion_recursif_victoire.ml
ocamlc graphics.cma matrix.cmo morpion_simple_prelude.cmo morpion_simple_debut.cmo morpion_simple_victoire.cmo morpion_recursif_prelude.cmo morpion_recursif_debut.cmo morpion_recursif_victoire.cmo morpion_recursif_imperatif.cmo -o morpion_recursif.byte
./morpion_recursif.byte
